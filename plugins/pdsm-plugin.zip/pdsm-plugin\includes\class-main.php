<?php

if (!defined('ABSPATH')) {
    exit;
}

class PDSM_Main {
    public function run() {
        $api = new PDSM_API();
        $site_manager = new PDSM_Site_Manager();

        if (is_admin()) {
            $admin = new PDSM_Admin();
        }
    }
}
