<?php

if (!defined('ABSPATH')) {
    exit;
}

class PDSM_Admin {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_plugin_page']);
        add_action('admin_init', [$this, 'page_init']);
        
        // Gera a chave de API na inicialização se ela não existir
        if (empty(get_option('pdsm_api_key'))) {
            update_option('pdsm_api_key', wp_generate_password(24, false));
        }
    }

    public function add_plugin_page() {
        add_menu_page(
            'Pack de Sites', 
            'Pack de Sites', 
            'manage_options', 
            'pdsm-manager', 
            [$this, 'create_admin_page'], 
            'dashicons-networking', 
            100
        );
    }

    public function create_admin_page() {
        $sites = get_option('pdsm_sites', []);
        $api_key = get_option('pdsm_api_key', '');
        $logs = get_option('pdsm_audit_logs', []);
        
        // Verifica se houve envio de formulário para adicionar novo site
        if (isset($_POST['pdsm_add_site_nonce']) && wp_verify_nonce($_POST['pdsm_add_site_nonce'], 'pdsm_add_site')) {
            if (isset($_POST['new_domain']) && !empty($_POST['new_domain'])) {
                $new_domain = sanitize_text_field($_POST['new_domain']);
                $new_api_key = isset($_POST['new_api_key']) ? sanitize_text_field($_POST['new_api_key']) : '';
                
                if (count($sites) < 10) {
                    $sites[$new_domain] = [
                        'domain'  => $new_domain,
                        'api_key' => $new_api_key,
                        'status'  => 'pending'
                    ];
                    update_option('pdsm_sites', $sites);
                    echo '<div class="notice notice-success is-dismissible"><p>Site adicionado com sucesso!</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>Limite de 10 sites atingido.</p></div>';
                }
            }
        }

        // Verifica deleção
        if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['domain']) && current_user_can('manage_options')) {
            $domain_to_delete = sanitize_text_field($_GET['domain']);
            if (isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'pdsm_delete_site_' . $domain_to_delete)) {
                if (isset($sites[$domain_to_delete])) {
                    unset($sites[$domain_to_delete]);
                    update_option('pdsm_sites', $sites);
                    echo '<div class="notice notice-success is-dismissible"><p>Site removido.</p></div>';
                }
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>Falha na verificação de segurança (nonce inválido).</p></div>';
            }
        }

        // Renderiza o template da página
        require_once PDSM_PLUGIN_DIR . 'admin/views/admin-page.php';
    }

    public function page_init() {
        // Registro de settings caso precisemos no futuro
    }
}
