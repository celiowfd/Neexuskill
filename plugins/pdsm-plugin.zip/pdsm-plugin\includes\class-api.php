<?php

if (!defined('ABSPATH')) {
    exit;
}

class PDSM_API {
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes() {
        register_rest_route('pdsm/v1', '/sites', [
            'methods'  => 'GET',
            'callback' => [$this, 'get_sites'],
            'permission_callback' => [$this, 'check_api_permission']
        ]);

        register_rest_route('pdsm/v1', '/update', [
            'methods'  => 'POST',
            'callback' => [$this, 'update_plugin'],
            'permission_callback' => [$this, 'check_api_permission']
        ]);
    }

    public function check_api_permission($request) {
        $api_key = $request->get_header('X-API-Key');
        // Basic validation for now - should be improved
        $valid_key = get_option('pdsm_api_key', '');
        if (empty($valid_key) || $api_key !== $valid_key) {
            return new WP_Error('rest_forbidden', 'Chave de API inválida.', ['status' => 401]);
        }
        return true;
    }

    public function get_sites() {
        $sites = get_option('pdsm_sites', []);
        return rest_ensure_response($sites);
    }

    public function update_plugin($request) {
        $plugin = sanitize_text_field($request->get_param('plugin'));
        $sites_raw  = $request->get_param('sites'); // Array de domínios
        $download_url = sanitize_text_field($request->get_param('download_url')); // Opcional: url recebida do agente

        if (empty($plugin)) {
            return new WP_Error('missing_param', 'Parâmetro plugin é obrigatório.', ['status' => 400]);
        }
        
        // Garante que $sites seja um array (pode vir nulo/vazio) e sanitizado
        $sites = [];
        if (is_array($sites_raw)) {
            $sites = array_map('sanitize_text_field', $sites_raw);
        }

        // Mock de uma URL de ZIP caso não seja providenciada pela Skill (apenas para Fase de Testes)
        if (empty($download_url)) {
            // Em produção, isso bateria numa API Central (repositório) para pegar o ZIP correto testado
            $download_url = 'https://downloads.wordpress.org/plugin/akismet.latest-stable.zip'; // Exemplo
        }

        $manager = new PDSM_Site_Manager();
        $site_results = $manager->update_plugin_on_sites($plugin, $sites, $download_url);

        $results = [
            'status' => 'completed',
            'message' => 'Processo de atualização finalizado.',
            'plugin' => $plugin,
            'details' => $site_results
        ];

        return rest_ensure_response($results);
    }
}
