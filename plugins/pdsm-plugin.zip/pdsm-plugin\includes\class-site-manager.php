<?php

if (!defined('ABSPATH')) {
    exit;
}

class PDSM_Site_Manager {
    private $sites = [];

    public function __construct() {
        $this->sites = get_option('pdsm_sites', []);
        
        // Registrar hook para o Job Queue via WP-Cron
        add_action('pdsm_async_update_job', [$this, 'process_async_update'], 10, 3);
    }

    public function add_site($domain, $api_key) {
        $this->sites[$domain] = [
            'domain'  => $domain,
            'api_key' => $api_key,
            'status'  => 'pending'
        ];
        update_option('pdsm_sites', $this->sites);
    }

    // Método assíncrono chamado pelo Cron
    public function process_async_update($domain, $plugin_slug, $download_url) {
        if (!isset($this->sites[$domain])) return;

        $api_key = $this->sites[$domain]['api_key'];
        
        // HMAC + Zero Trust Setup
        $timestamp = time();
        $nonce = wp_generate_password(16, false);
        $payload = wp_json_encode([
            'plugin' => $plugin_slug,
            'download_url' => $download_url
        ]);
        
        // Assinatura: HMAC-SHA256( payload + timestamp + nonce, api_key )
        $signature = hash_hmac('sha256', $payload . $timestamp . $nonce, $api_key);

        $response = wp_remote_post("https://{$domain}/wp-json/pdsm-client/v1/update", [
            'headers' => [
                'Content-Type'   => 'application/json',
                'X-PDSM-Signature' => $signature,
                'X-PDSM-Timestamp' => $timestamp,
                'X-PDSM-Nonce'     => $nonce
            ],
            'body' => $payload,
            'timeout' => 90 // Atualização pode demorar com backup/rollback
        ]);

        // Trilha de auditoria - salva o log do resultado
        $logs = get_option('pdsm_audit_logs', []);
        $log_entry = [
            'time' => current_time('mysql'),
            'domain' => $domain,
            'plugin' => $plugin_slug,
        ];

        if (is_wp_error($response)) {
            $log_entry['status'] = 'error';
            $log_entry['message'] = $response->get_error_message();
        } else {
            $code = wp_remote_retrieve_response_code($response);
            $log_entry['status'] = ($code >= 200 && $code < 300) ? 'success' : 'error';
            $log_entry['message'] = wp_remote_retrieve_body($response);
        }

        // Mantém apenas os últimos 100 logs
        array_unshift($logs, $log_entry);
        if (count($logs) > 100) array_pop($logs);
        update_option('pdsm_audit_logs', $logs);
    }

    public function update_plugin_on_sites($plugin_slug, $sites_list = [], $download_url = '') {
        $results = [];
        
        if (empty($sites_list)) {
            $sites_list = array_keys($this->sites);
        }

        foreach ($sites_list as $domain) {
            if (!isset($this->sites[$domain])) {
                $results[$domain] = ['status' => 'error', 'message' => 'Site não cadastrado.'];
                continue;
            }

            // Enfileira o trabalho assíncrono para não travar o servidor
            wp_schedule_single_event(time(), 'pdsm_async_update_job', [$domain, $plugin_slug, $download_url]);

            $results[$domain] = [
                'status' => 'queued',
                'message' => 'Trabalho assíncrono agendado com sucesso (Zero Trust HMAC ativado).'
            ];
        }

        return $results;
    }

    public function check_updates() {
        // ... Lógica anterior mantida (poderia ser adaptada para HMAC no futuro)
        return [];
    }
}
