<?php

if (!defined('ABSPATH')) {
    exit;
}

class PDSM_Client_API {

    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes() {
        register_rest_route('pdsm-client/v1', '/update', [
            'methods'  => 'POST',
            'callback' => [$this, 'process_update'],
            'permission_callback' => [$this, 'check_permission']
        ]);
    }

    public function check_permission($request) {
        $signature = $request->get_header('X-PDSM-Signature');
        $timestamp = (int) $request->get_header('X-PDSM-Timestamp');
        $nonce     = sanitize_text_field($request->get_header('X-PDSM-Nonce'));
        $valid_key = get_option('pdsm_client_api_key', '');
        
        if (empty($valid_key) || empty($signature) || empty($timestamp) || empty($nonce)) {
            return new WP_Error('rest_forbidden', 'Faltam headers de autenticação Zero Trust.', ['status' => 401]);
        }

        // 1. Validar Timestamp (prevenir replay attack, max 5 min de diferença)
        if (abs(time() - $timestamp) > 300) {
            return new WP_Error('rest_forbidden', 'Timestamp expirado (possível replay attack).', ['status' => 401]);
        }

        // 2. Validar Nonce (prevenir replay attack imediato)
        $nonce_cache = get_transient('pdsm_nonce_' . $nonce);
        if ($nonce_cache) {
            return new WP_Error('rest_forbidden', 'Nonce já utilizado.', ['status' => 401]);
        }
        set_transient('pdsm_nonce_' . $nonce, true, 600); // guarda por 10 min

        // 3. Validar HMAC
        $payload = $request->get_body();
        $expected_signature = hash_hmac('sha256', $payload . $timestamp . $nonce, $valid_key);

        if (!hash_equals($expected_signature, $signature)) {
            return new WP_Error('rest_forbidden', 'Assinatura HMAC inválida.', ['status' => 401]);
        }

        return true;
    }

    public function process_update($request) {
        $plugin_slug = sanitize_text_field($request->get_param('plugin')); 
        $download_url = esc_url_raw($request->get_param('download_url')); 

        if (empty($plugin_slug) || empty($download_url)) {
            return new WP_Error('missing_params', 'Parâmetros plugin e download_url são obrigatórios.', ['status' => 400]);
        }

        $updater = new PDSM_Updater();
        $result = $updater->update_plugin_with_rollback($plugin_slug, $download_url);

        if (is_wp_error($result)) {
            return rest_ensure_response([
                'status' => 'error',
                'message' => $result->get_error_message()
            ]);
        }

        return rest_ensure_response([
            'status' => 'success',
            'message' => "Plugin {$plugin_slug} atualizado via fluxo seguro."
        ]);
    }
}
